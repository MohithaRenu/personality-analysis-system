# backend/app/utils/personality_utils.py

def analyze_text(text):
    # Dummy implementation - replace this with real personality logic
    return {
        "openness": 0.85,
        "conscientiousness": 0.76,
        "extraversion": 0.64,
        "agreeableness": 0.92,
        "neuroticism": 0.48
    }
